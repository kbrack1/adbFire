#!/system/bin/sh

mount -o remount,rw /system

cd /system/xbin
for f in $(busybox find /system/xbin -type l) ; 
do 
 bblnk=$(busybox readlink $f) ; 
  if echo "$bblnk" | busybox grep -q busybox ;
  then
   busybox rm $f
  fi ;
done

/system/xbin/ssh stop
/system/xbin/samba stop


rm /system/etc/install-recovery-2.sh
rm /system/xbin/busybox
rm /system/xbin/aftv-unlock
rm /system/xbin/ntfs-3g
rm /system/xbin/mount.exfat-fuse
mv /system/xbin/mntdrives.sh /system/xbin/mntdrives.backup
rm /system/xbin/mntdata.orig
rm /system/xbin/binstall.sh
rm /system/xbin/buninstall.sh
rm /system/xbin/init.bueller.sh
rm /system/xbin/mkboot.sh
rm /system/xbin/mntdrives.sh
rm /system/xbin/mntdrives1.sh
rm /system/xbin/mntdrives2.sh
rm /system/xbin/restboot.sh
rm /system/xbin/rootmnt
rm /system/xbin/remount


if [ -e "/system/xbin/mntdata.sh" ];
 then
 mv /system/xbin/mntdata.sh /system/xbin/mntdata.backup;
fi

if [ -e "/data/data/com.funkyfresh.samba/files/jocala.txt" ];
 then
  rm -r /data/data/com.funkyfresh.samba;
fi

rm /system/xbin/ssh*
rm /system/xbin/rsync
rm /system/xbin/dbclient
rm /system/xbin/scp
rm /system/xbin/samba
rm /system/xbin/mount_ufsd_fuse


rm -r /system/etc/init.d
rm -r /data/jocala
mv /system/etc/init.bueller.sh.old /system/etc/init.bueller.sh

mount -o remount,ro /system

