#!/system/bin/sh

mount -o remount,rw /system
rm /system/xbin/binstall.sh
rm /sdcard/binstall.sh
rm /sdcard/buninstall.sh
rm /sdcard/ntfs-3g
rm /sdcard/mount.exfat-fuse
rm /sdcard/mntdrives.sh

mount -o remount,ro /system
