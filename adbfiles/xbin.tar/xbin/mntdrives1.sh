#!/system/bin/sh


#
#  FireTV USB Drive Mounter
#
#  REQUIRED: Busybox with suuport for run-parts, blkid, mount-helper
#  mount-helper and stuff that's probably slipped my mind required.
#  AFAIK, NONE of the "free" Play Store busyboxes have all of the
#  supplied options. I suggest you use mine or compile your own.
#
#  This script has been tested with 4 drives
#  mounted (vfat,exfat,ntfs,ext4)
#  but (in theory) should support 26 (sda1-sdz1)
#
#  This script mounts your drives in the order
#  they are encountered at mountpoints
#  /storage/usb/drive1,drive2,etc.
#  if you want to control the mountpoint for
#  your drives mount via UUID with mntdrives2.sh
#
#
#  Enjoy!   jocala@jocala.com
#


sleep 20

i=0

storage="/storage/usb"


if [[ $(ls /dev/block | $busybox grep -c 'sd') -eq 0 ]]; then 
	exit 0
fi

mount -o remount,rw / ;


for f in /dev/block/sd??; do 
        drive=`echo $f | sed -r 's/^.{11}//'`
	mountType=$(busybox blkid $f | busybox sed -n -e 's_^.*TYPE="\([^\"]*\)".*_\1_p');
	mountUUID=$(busybox blkid $f | busybox sed -n -e 's_^.*UUID="\([^\"]*\)".*_\1_p');

i=$((i+1))

  busybox mkdir -p $storage/drive$i;
  chmod -R 0755 $storage/drive$i;

  if [[ $mountType == "exfat" ]]; then
     mount.exfat-fuse -o rw $f $storage/drive$i
  fi

  if [[ $mountType == "ntfs" ]]; then
  	ntfs-3g $f $storage/drive$i -o rw,sync
  fi

  if [[ $mountType == "ext4" ]] || [[ $mountType == "ext3" ]] || [[ $mountType == "ext2" ]] || [[ $mountType == "vfat" ]]; then
    busybox mount UUID=$mountUUID $storage/drive$i
  fi

done  

mount -o remount,ro / 


if [ $# -ge 1 ];
then 
   sleep 20
   /data/data/com.funkyfresh.samba/files/samba-rc start
fi
